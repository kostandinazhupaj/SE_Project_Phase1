<?php
use PHPUnit\Framework\TestCase;

class ExpenseTest extends TestCase
{
    public function testAddExpenseSuccess()
    {
        // Simulate session
        $_SESSION['detsuid'] = 1;

        // Simulate form input
        $_POST['expense_date'] = '2024-05-20';
        $_POST['expense_item'] = 'Test Expense Item';
        $_POST['cost'] = '50';

        // Start output buffering to capture HTML output
        ob_start();
        include 'path/to/your/file.php'; // Replace with the path to your PHP file
        $output = ob_get_clean();

        // Assertions
        $this->assertStringContainsString('Expense has been added', $output);
        $this->assertStringContainsString('manage-expense.php', $output); // Check for redirection
    }

    public function testAddExpenseFailure()
    {
        // Simulate session
        $_SESSION['detsuid'] = 1;

        // Simulate form input
        $_POST['expense_date'] = '2024-05-20';
        $_POST['expense_item'] = 'Test Expense Item';
        $_POST['cost'] = 'InvalidCost'; // Simulating invalid input

        // Start output buffering to capture HTML output
        ob_start();
        include 'path/to/your/file.php'; // Replace with the path to your PHP file
        $output = ob_get_clean();

        // Assertions
        $this->assertStringContainsString('Something went wrong. Please try again!', $output);
    }
}
