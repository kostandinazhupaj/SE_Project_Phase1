<?php

session_start();
error_reporting(0);
include('config.php');

?>  

<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
    <div class="container-fluid">

        <div class="navbar-header"> 
            <a href="dashboard.php" class="navbar-brand">
                <span>Daily Expense Tracker</span>
            </a>
            <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse">
                <span class="sr-only sr-only-focusable">Toggle Navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        
    </div>
</nav>