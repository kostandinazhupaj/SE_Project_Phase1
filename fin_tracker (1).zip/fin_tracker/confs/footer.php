<div class="col-xs-12 col-xs-offset-3 col-sm-12 col-sm-offset-6 col-md-12 col-md-offset-5">
    <p style="font-size: medium">Smart money, smart life </p>
</div>  